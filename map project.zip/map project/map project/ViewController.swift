//
//  ViewController.swift
//  map project
//
//  Created by MacStudent on 2017-10-27.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController ,CLLocationManagerDelegate, UISearchBarDelegate{
    
    
    @IBOutlet weak var mapView: MKMapView!
    let initialLocation = CLLocation(latitude: 43.6532, longitude: -79.3832)
     let lambtoncollege = CLLocation(latitude: 43.773257,  longitude: -79.335899)
    let regionRadius: CLLocationDistance = 1000
    var locationManager = CLLocationManager()
    
    override func viewDidLoad(){
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        mapView.mapType = MKMapType.satellite
        
        mapView.isPitchEnabled = true
        mapView.isZoomEnabled = true
        mapView.isScrollEnabled = true
        mapView.showsUserLocation = true
        
       centerMapOnLocation(location: initialLocation)
        //setPointAnnotation(location: initialLocation, title: "city hall", subTitle: "123 kking street west")
        setPointAnnotation(location: initialLocation, title: "lambton college", subTitle: "267 yarklans blvd. nortyork")
        
        
        
        //*****permissions******//
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        DispatchQueue.main.async {
            
            self.locationManager.startUpdatingLocation()
        }
        
        
    }
    
   func centerMapOnLocation(location: CLLocation) {
    let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                regionRadius, regionRadius)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    func setPointAnnotation(location: CLLocation,title: String, subTitle: String){
        // Drop a pin at user's Current Location
        
        
        
        //Clear all pointer
        if self.mapView.annotations.count != 0{
            let annotation = self.mapView.annotations[0]
            self.mapView.removeAnnotation(annotation)
        }
        
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
       myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
        myAnnotation.title = title
        myAnnotation.subtitle = subTitle
        mapView.addAnnotation(myAnnotation)
    }
    

    @IBAction func changeMapType(_ sender: UISegmentedControl) {
        
        
        if sender.selectedSegmentIndex == 0 {
            mapView.mapType = MKMapType.standard
            
        } else{
                mapView.mapType = MKMapType.satellite
            }
        
    }
    // current locaiton
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let currentLocation = locations[0]
        setPointAnnotation(location: currentLocation, title: "current Location", subTitle: "sub title")
    }
    
}



